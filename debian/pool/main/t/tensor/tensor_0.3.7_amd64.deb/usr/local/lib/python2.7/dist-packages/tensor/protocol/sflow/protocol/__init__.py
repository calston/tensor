from tensor.protocol.sflow.protocol import protocol

Sflow = protocol.Sflow
FlowSample = protocol.FlowSample
CounterSample = protocol.CounterSample
